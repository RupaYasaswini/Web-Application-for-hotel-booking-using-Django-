from django import forms

ROOM_CHOICES =(
    ("1","Standard"),
    ("2","Classic"),
    ("3","Deluxe")
)


class ChoiceForm(forms.Form):
    room_type = forms.ChoiceField(
        choices=ROOM_CHOICES
    )
    no_of_rooms = forms.IntegerField()

